"""Base state for the app."""

import reflex as rx


class State(rx.State):
    """Base state for the app.

    The base state is used to store general vars used throughout the app.
    the guy, i asked if he saw someone sleeping under the table
    he said yah
    then i said, yah idk how ppeople see that and take the table, that kinda weird
    but i didnt know he was with them
    juan was using a chair, the
    """

    pass
